<?php include("header.php"); ?>
    <title>Register Page</title>
  </head>
  <body>
     <!--nav-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="#">Get Registered !!</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor01">
    
  <button class="btn btn-primary" name="login" ><a href="<?php echo base_url();?>index.php/auth/login"><font color="white">Login Now!</a>
     </font></button>
  </div>
</nav>
     <!--navends-->
     <div class="row">
     <div class="col-lg-4"  >
    </div>
    <div class="col-lg-4" >
    <h1>Register Page</h1>
    <p>Fill the following page details to get registered</p>
   
   <?php if(isset($_SESSION['success'])) {

   ?>
   <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
   <?php } 
   ?>
   <?php echo validation_errors('<div class="alert alert-danger">','</div>'); ?>

    <form action="" method="POST">
     <div class="form-group">
       <label for="username" class="label-default">Username:</label>
       <input class="form-control" name="username" id="username" type="text">
     </div>
     <div class="form-group">
       <label for="email" class="label-default">Email:</label>
       <input class="form-control" name="email" id="email" type="text">
     </div>
     <div class="form-group">
       <label for="password" class="label-default">Password:</label>
       <input class="form-control" name="password" id="password" type="password">
     </div>
     <div class="form-group">
       <label for="password" class="label-default">Confirm Password:</label>
       <input class="form-control" name="password2" id="password" type="password">
     </div>
     <div class="form-group">
       <label for="gender" class="label-default">Gender:</label>
       <select class="form-control" name="gender" id="gender">
          <option value="Male">Male</option>
          <option value="Female">Female</option>
       </select>
     </div>
     <div class="form-group">
       <label for="phone" class="label-default">Phone:</label>
       <input class="phone" name="phone" id="phone" type="text">
     </div>
     <div class="text-center">
     <button class="btn btn-primary" name="register">Register</button>
     </div>
     </form>
    </div>
   </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <?php include('footer.php'); ?>