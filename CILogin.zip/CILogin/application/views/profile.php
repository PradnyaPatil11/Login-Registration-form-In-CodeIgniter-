<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Login Page</title>
  </head>
  <body>
    
    <div class="col-lg-5 col-lg-offset-2" >
    <h1>Profile  Page</h1>
    
   
   <?php if(isset($_SESSION['success'])) {

   ?>
   <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
   <?php } 
   ?>
   HELLO ,<?php echo $_SESSION['username']; ?>

   <br><br>
   <a href="<?php echo base_url();?>index.php/auth/logout">Logout</a>

    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <?php include('footer.php'); ?>